# kali nethunter patches
kali nethunter patches for 4.4-4.19 kernel.

patches from:
https://gitlab.com/kalilinux/nethunter/build-scripts/kali-nethunter-kernel
